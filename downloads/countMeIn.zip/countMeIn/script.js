// js

// open the console window of any browser to see console.log() messages,
// like print() messages in Processing
console.log('reading js');

// declare a variable called "n" and initialize it to an empty string

// write a loop that makes seven calls to console.log to output lines of increasing numbers 1, 12, 123 ...
